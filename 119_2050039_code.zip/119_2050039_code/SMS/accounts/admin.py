from django.contrib import admin
from accounts.models import CustomUser, Teacher, Student

class StudentAdmin(admin.ModelAdmin):
    list_display=['id','last_login','username','full_name','email','gender','course','level','is_active']
    list_display_links=['id']
    list_editable = ['last_login','username','full_name','email','gender','course','level','is_active']

class TeacherAdmin(admin.ModelAdmin):
    list_display=['id','last_login','username','full_name','email','gender','course','four','five','six','is_active']
    list_display_links=['id']
    list_editable = ['last_login','username','full_name','email','gender','course','four','five','six','is_active']

admin.site.register(CustomUser)
admin.site.register(Teacher, TeacherAdmin)
admin.site.register(Student,StudentAdmin)



