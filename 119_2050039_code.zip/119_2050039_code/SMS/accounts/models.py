from tabnanny import verbose
from django.db import models
from django.contrib.auth.models import AbstractUser


class CustomUser(AbstractUser):
    full_name = models.CharField(max_length=200, blank=True)
    gender = models.CharField(max_length=200, blank=True)
    course = models.CharField(max_length=200, blank=True)
    


class Student(CustomUser):
    level = models.CharField(max_length=200)
    class Meta:
        verbose_name="Student"

class Teacher(CustomUser):
    # user=models.OneToOneField(CustomUser,on_delete=models.CASCADE)
    four=models.CharField(max_length=200)
    five=models.CharField(max_length=200)
    six=models.CharField(max_length=200)
    class Meta:
        verbose_name="Teacher"



