from django.urls import path
from .views import login_view,register_view,register_teacher_view,choose_view, reset_password_view, logout_view


urlpatterns=[
    path('',login_view, name='login_view'),
    path('register/',register_view, name='register_view'),
    path('register_teacher/',register_teacher_view, name='register_teacher_view'),
    path('choose/',choose_view, name='choose_view'),
    path('reset-password/',reset_password_view, name='reset_password_view'),
    path('logout/',logout_view, name='logout_view'),
]