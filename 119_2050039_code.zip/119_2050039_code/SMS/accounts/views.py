from msilib.schema import Error
from optparse import Values
from django.shortcuts import redirect, render
from django.contrib import messages
from django.contrib.auth import get_user_model, logout
from django.contrib.auth.models import auth
from content.models import Course, Level, Module
from accounts.models import Student, Teacher, CustomUser
from numpy import empty
from django.contrib.auth.hashers import make_password
from django.http import HttpResponse, HttpResponseNotFound


def login_view(request):
    if request.method=='POST':
        user_id=request.POST['user_id']
        password=request.POST['password']

        user=auth.authenticate(username=user_id,password=password)

        all_user=CustomUser.objects.filter(username=user_id).values('is_active')

        for a in all_user:
            val_all_user=a['is_active']
            print(val_all_user)
        
        print(request.user)
        if user is not None:
        
            if val_all_user==True:
                val="lol"
                try:
                    iddd=Teacher.objects.filter(username=user_id).values('username')
                    for i in iddd:
                        val=i['username']
                except:
                    pass

                if (user_id==val):    
                    if user is not None:
                        auth.login(request,user)
                        return redirect('/home.teacher/')
                        
                    else:
                        messages.info(request,'Invalid login credentials')
                        return redirect('/')
                else:
                        if user is not None:
                            auth.login(request,user)
                            return redirect('/home/')
                        else:
                            messages.info(request,'Invalid login credentials')
                            return redirect('/')
                    
            else:
                messages.info(request,'Your account is yet to be confirmed by the admin')
        else:
            messages.info(request,'Invalid login credentials')



    elif request.method=='GET':
        # session continue code
        user_id=request.user

        value="test"
        # checking if the user is a teacher
        try:
            teacher_user=Teacher.objects.filter(username=user_id).values('username')
            print(teacher_user)

            for i in teacher_user:
                value=i['username']
                value="updated"
        except:
            pass
        

        print(user_id==value)
        if request.user.is_authenticated:
            if request.user.is_superuser:
                return render(request, 'accounts/login.html')

            elif (value=="updated"):
                print("tttttttttttttttttttttttttttttttttttttttttttttttt")
                return redirect('/home.teacher/')

            else:
                print("ssssssssssssssssssssssssssssssssssssssssss")
                return redirect('/home/')

                

    return render(request, 'accounts/login.html')

def register_view(request):
    course = Course.objects.all()
    level = Level.objects.all()
    context = {
        'course':course,
        'level': level
        }

    if request.method=='POST':
        full_name=request.POST['full_name']
        user_id=request.POST['user_id']
        email=request.POST['email']
        password=request.POST['password']
        confirm_password=request.POST['confirm_password']
        gender=request.POST['gender']
        course=request.POST['course']
        level=request.POST['level']
        User=Student

        if not full_name or not user_id or not email or not password or not confirm_password:
            messages.info(request,"You must fill all the fields")
        else:
            if not len(password)<8:
                if password==confirm_password:
                    
                    if User.objects.filter(username=user_id).exists():
                        messages.info(request,"This user ID is already taken")
                        return redirect('/register')
                    else:
                        user=User.objects.create_user(full_name=full_name, username=user_id, email=email, password=password,gender=gender,course=course,level=level)
                        user.is_active=False
                        user.save();
                        messages.info(request,"Registration successful")
                        print("user created")
                else:
                    messages.info(request, "Your password does not match")
                    return redirect('/register')
            else:
                messages.info(request, "Your password must not be less than 8 characters")
                return redirect('/register')
            return redirect('/') 
        return redirect('/register')    
    return render(request, 'accounts/register.html', context)



def register_teacher_view(request):
    course = Course.objects.all()
    level=Level.objects.all()
    four=Module.objects.filter(level='Four').values('module')
    five=Module.objects.filter(level='Five').values('module')
    six=Module.objects.filter(level='Six').values('module')
    context = {
        'course':course,
        'level':level,
        'four':four,
        'five':five,
        'six':six
        }

    if request.method=='POST':
        full_name=request.POST['full_name']
        user_id=request.POST['user_id']
        email=request.POST['email']
        password=request.POST['password']
        confirm_password=request.POST['confirm_password']
        gender=request.POST['gender']
        course=request.POST['course']
        four=request.POST['four']
        five=request.POST['five']
        six=request.POST['six']


        User=Teacher

        if not full_name or not user_id or not email or not password or not confirm_password:
            messages.info(request,"You must fill all the fields")
        else:
            if not len(password)<8:
                if password==confirm_password:
                    
                    if User.objects.filter(username=user_id).exists():
                        messages.info(request,"This user ID is already taken")
                        return redirect('/register_teacher')
                    else:
                        user=User.objects.create_user(full_name=full_name, username=user_id, email=email, password=password, gender=gender, course=course, four=four, five=five, six=six)
                        user.is_active=False
                        user.save(); 
                        messages.info(request,"Registration successful")
                        print("user created")
                else:
                    messages.info(request, "Your password does not match")
                    return redirect('/register_teacher')
            else:
                messages.info(request, "Your password must not be less than 8 characters")
                return redirect('/register_teacher')
            return redirect('/') 
        return redirect('/register_teacher')    
    return render(request, 'accounts/register_teacher.html',context)


def choose_view(request):
    return render(request, 'accounts/choose.html')

def reset_password_view(request):
    if request.method=='POST':
        user_id=request.POST['user_id']
        new_password=request.POST['new_pwd']
        confirm_password=request.POST['confirm_pwd']

        try:

            if not user_id or not confirm_password or not new_password:
                messages.info(request,"You must fill all the fields")
            else:
                if not len(new_password)<8:
                    if confirm_password==new_password:     
                        user=CustomUser.objects.get(username=user_id)
                        user.password=make_password(new_password)
                        user.save();
                        messages.info(request,"Password changed")
                    else:
                        messages.info(request, "Your password does not match")
                        return redirect('/reset-password')
                else:
                    messages.info(request, "Your password must not be less than 8 characters")
                    return redirect('/reset-password')
                return redirect('/') 
        except:
            messages.info(request, "Invalid data")
        return redirect('/reset-password')


       
    return render(request, 'accounts/reset_password.html')



def logout_view(request):
    logout(request)
    return redirect('/')


