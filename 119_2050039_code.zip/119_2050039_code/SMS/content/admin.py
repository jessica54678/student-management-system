from django.contrib import admin
from content.models import Module, Course, Level,Notice,Certificate,Result, Assignment,Assignment_student,Announcement



class ResultAdmin(admin.ModelAdmin):
    list_display=['result_id','student_name','course','level','module','student_id','marks','is_active']
    list_editable = ['marks','is_active']

class CertificateAdmin(admin.ModelAdmin):
    list_display=['certificate_id','user_id','full_name','certificate_reason','certificate_date']
    list_editable = ['certificate_id','user_id','full_name','certificate_reason']
    list_display_links=['certificate_date']

class ModuleAdmin(admin.ModelAdmin):
    list_display=['module','course','level','description']
    list_display_links=['module']

class NoticeAdmin(admin.ModelAdmin):
    list_display=['notice_id','notice_title','notice','notice_date']
    list_display_links=['notice_title']    

class AssignmentAdmin(admin.ModelAdmin):
    list_display=['assignment_id','teacher_id','course_id','module_id','due_date','due_time','title','extra_file']
    list_display_links=['assignment_id'] 

class AnnouncementAdmin(admin.ModelAdmin):
    list_display=['announcement_id','teacher_id','course_id','module_id','title','extra_file']
    list_display_links=['announcement_id'] 

class AssignmentStudentAdmin(admin.ModelAdmin):
    list_display=['assignment_id','real_assignment_id','student_id','course_id','module_id','file','submitted_on']
    list_display_links=['assignment_id'] 

admin.site.register(Course)
admin.site.register(Level)
admin.site.register(Module,ModuleAdmin)
admin.site.register(Notice, NoticeAdmin)
admin.site.register(Certificate,CertificateAdmin)
admin.site.register(Result,ResultAdmin)
admin.site.register(Assignment, AssignmentAdmin)
admin.site.register(Announcement, AnnouncementAdmin)
admin.site.register(Assignment_student, AssignmentStudentAdmin)




