from pyexpat import model
from statistics import mode
from tokenize import Number
from django.db import models

from accounts.models import Student, Teacher, CustomUser

# Create your models here.

class Course(models.Model):
    course = models.CharField(max_length=200, primary_key=True)


class Level(models.Model):
    level = models.CharField(max_length=200, primary_key=True)

class Module(models.Model):
    module = models.CharField(max_length=200, primary_key=True)
    course=models.ForeignKey(Course, default="BBA",on_delete=models.CASCADE)
    level=models.ForeignKey(Level, default="Four",on_delete=models.CASCADE)
    description = models.TextField(default="With the help of this module you will gain information on",blank=True)


class Assignment(models.Model):
    assignment_id=models.AutoField(primary_key=True)
    teacher_id=models.ForeignKey(CustomUser, default="none",on_delete=models.CASCADE, blank=True)
    course_id=models.ForeignKey(Course, default="none",on_delete=models.CASCADE, blank=True)
    # level_id=models.ForeignKey(Level, default="none",on_delete=models.CASCADE, blank=True)
    module_id=models.ForeignKey(Module, default="none",on_delete=models.CASCADE, blank=True)
    due_date=models.DateField()
    due_time=models.TimeField()
    title=models.CharField(max_length=200, blank=True)
    information=models.TextField(default="information",blank=True)
    extra_file=models.FileField(upload_to='assignment',blank=True)

class Assignment_student(models.Model):
    assignment_id=models.AutoField(primary_key=True)
    real_assignment_id=models.ForeignKey(Assignment,on_delete=models.CASCADE, null=True)
    student_id=models.ForeignKey(CustomUser, default="none",on_delete=models.CASCADE, blank=True)
    course_id=models.ForeignKey(Course, default="none",on_delete=models.CASCADE, blank=True)
    module_id=models.ForeignKey(Module, default="none",on_delete=models.CASCADE, blank=True)
    file=models.FileField(upload_to='media')
    submitted_on=models.DateTimeField(auto_now_add=True)


class Announcement(models.Model):
    announcement_id=models.AutoField(primary_key=True)
    teacher_id=models.ForeignKey(CustomUser, default="none",on_delete=models.CASCADE, blank=True)
    course_id=models.ForeignKey(Course, default="none",on_delete=models.CASCADE, blank=True)
    # level_id=models.ForeignKey(Level, default="none",on_delete=models.CASCADE, blank=True)
    module_id=models.ForeignKey(Module, default="none",on_delete=models.CASCADE, blank=True)
    title=models.CharField(max_length=200, blank=True)
    information=models.TextField(default="information",blank=True)
    extra_file=models.FileField(upload_to='announcement',blank=True)


class Notice(models.Model):
    notice_id=models.AutoField(primary_key=True)
    notice_title=models.CharField(max_length=200, blank=True)
    notice=models.TextField(default="This notice is to inform you that ",blank=True)
    notice_date=models.DateTimeField(auto_now_add=True)

class Certificate(models.Model):
    certificate_id=models.AutoField(primary_key=True)
    user_id=models.ForeignKey(CustomUser, default="none",on_delete=models.CASCADE, blank=True)
    full_name = models.CharField(max_length=200, blank=True)
    certificate_reason= models.CharField(max_length=200, blank=True)
    certificate_date=models.DateField(auto_now_add=True)


class Result(models.Model):
    result_id=models.AutoField(primary_key=True)
    student_id= models.ForeignKey(CustomUser, default="none",on_delete=models.CASCADE, blank=True)
    module = models.ForeignKey(Module,default="Principles of Marketing",on_delete=models.CASCADE)
    course=models.ForeignKey(Course, default="BBA",on_delete=models.CASCADE)
    level=models.ForeignKey(Level, default="Four",on_delete=models.CASCADE)
    marks=models.IntegerField()
    student_name=models.CharField(max_length=200, blank=True)
    is_active=models.BooleanField(default=False)