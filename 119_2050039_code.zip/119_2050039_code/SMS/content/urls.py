from os import stat
from django.urls import path
from django.contrib.auth import views as auth_views
from .views import home_view, index_view, home__teacher_view, assignment_teacher_view, assignment_student_view,notice_view,notice_teacher_view, certificate_view,pdf_certificate,result_teacher,result_student_view,pdf_certificate_teacher,certificate_teacher_view,profile_student_view,profile_teacher_view,exam_view

from django.conf.urls.static import static
from django.conf import settings

urlpatterns=[
    path('index/',index_view, name='index_view'),
    path('home/',home_view, name='home_view'),
    path('home.teacher/',home__teacher_view, name='home__teacher_view'),
    path('assignment.teacher/',assignment_teacher_view, name='assignment_teacher_view'),
    # path('assignment.teacher/<str:subject>',assignment_teacher_view, name='assignment_teacher_view'),

    path('assignment.student/',assignment_student_view, name='assignment_student_view'),
    path('notice/',notice_view, name='notice_view'),
    path('notice-teacher/',notice_teacher_view, name='notice_teacher_view'),
    path('certificate/',certificate_view, name='certificate_view'),
    path('certificate-teacher/',certificate_teacher_view, name='certificate_teacher_view'),
    path('pdf_certificate/',pdf_certificate, name='pdf_certificate'),
    path('pdf_certificate_teacher/',pdf_certificate_teacher, name='pdf_certificate_teacher'),
    path('result-teacher/',result_teacher, name='result_teacher'),
    path('result-student/',result_student_view, name='result_student_view'),

    path('profile-student/',profile_student_view, name='profile_student_view'),
    path('profile-teacher/',profile_teacher_view, name='profile_teacher_view'),

    path('online-exam/',exam_view, name='exam_view'),









  


    
]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)