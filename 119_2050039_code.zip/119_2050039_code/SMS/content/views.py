from ast import Assign
import imp
from mmap import PAGESIZE
from multiprocessing.sharedctypes import Value
import re
from urllib import request
from django.http import HttpResponse
from django.shortcuts import render, redirect
from matplotlib.pyplot import get
from matplotlib.style import context
from pytest import mark
from content.models import Course, Level, Module, Assignment, Announcement, Notice, Certificate,Assignment_student,Result
from accounts.models import Student, Teacher, CustomUser
from django.contrib.auth.decorators import login_required
from accounts.views import login_view
from django.contrib.auth.models import User
from django.contrib import messages
from datetime import datetime



# for converting template to pdf
from django.http import FileResponse
import io
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter


from django.template.loader import get_template
from xhtml2pdf import pisa



def index_view(request):
    return render(request, 'content/index.html')


@login_required()
def home_view(request):
    if request.method=='GET':
        user_id=request.user
        print(user_id)
        course=CustomUser.objects.filter(username=user_id).values('course')
        print(course)
        for c in course:
            val_course=c['course']
            print(val_course)

        level=Student.objects.filter(username=user_id).values('level')
        print(level)
        for l in level:
            val_level=l['level']
            print(val_level)


        modules=Module.objects.filter(course_id=val_course, level_id=val_level).values('module')
        description=Module.objects.filter(course_id=val_course, level_id=val_level).values('description')


        for m in modules:
            val_module=m['module']
            print(val_module)

        for d in description:
            val_description=d['description']
            print(val_description)
        

        context = {
        'module':modules,
        'description':description
        }
    return render(request, 'content/home.html', context)
 
@login_required()
def home__teacher_view(request):
    if request.method=='GET':
        user_id=request.user
        print(user_id)
        course=CustomUser.objects.filter(username=user_id).values('course')
        print(course)
        for c in course:
            val_course=c['course']
            print(val_course)

        four=Teacher.objects.filter(username=user_id).values('four')
        five=Teacher.objects.filter(username=user_id).values('five')
        six=Teacher.objects.filter(username=user_id).values('six')
        print(four)
        print(five)
        print(six)

        for f in four:
            val_four=f['four']
            print(val_four)

        for f in five:
            val_five=f['five']
            print(val_five)
    
        for s in six:
            val_six=s['six']
            print(val_six)


        four=Module.objects.filter(course_id=val_course, module=val_four).values('module')
        five=Module.objects.filter(course_id=val_course, module=val_five).values('module')
        six=Module.objects.filter(course_id=val_course, module=val_six).values('module')

        for m in four:
            val_module=m['module']
            print(val_module)

        for m in five:
            val_module=m['module']
            print(val_module)
        
        for m in six:
            val_module=m['module']
            print(val_module)


        description_four=Module.objects.filter(course_id=val_course, module=val_four).values('description')
        description_five=Module.objects.filter(course_id=val_course, module=val_five).values('description')
        description_six=Module.objects.filter(course_id=val_course, module=val_six).values('description')


      
        for d in description_four:
            val_description=d['description']
            print(val_description)

        for d in description_five:
            val_description=d['description']
            print(val_description)
        
        for d in description_six:
            val_description=d['description']
            print(val_description)

        context = {
        'four':four,
        'five':five,
        'six':six,
        'description_four': description_four,
        'description_five': description_five,
        'description_six':description_six
        }
    return render(request, 'content/home_teacher.html', context)
 
  
@login_required()
def assignment_teacher_view(request):

    module_name=request.GET.get('name')
    print(module_name)
    
        

    assignment_send=list(Assignment.objects.filter(module_id_id=module_name).values_list('assignment_id','due_date','due_time','extra_file', 'module_id_id', 'information','title').order_by('-assignment_id'))
    
    announcement=list(Announcement.objects.filter(module_id_id=module_name).values_list('announcement_id','title','information','extra_file','module_id_id').order_by('-announcement_id'))

    student_assignment_id=Assignment_student.objects.filter(module_id_id=module_name).values_list('real_assignment_id_id','file','submitted_on').order_by('-real_assignment_id_id')      

        
    if request.method=='POST':

        user_id=request.user
        course=CustomUser.objects.filter(username=user_id).values('course')
        for c in course:
            val_course=c['course']

        teacher_id=user_id
        
        # if the create assignmemnt form is selected
        if 'datepicker' in request.POST and  request.FILES.get('choose_file'):
            due_date=request.POST['datepicker']
            due_time=request.POST['timepicker']
            extra_file=request.FILES.get('choose_file')
            title=request.POST['assignment_title']
            information=request.POST['assignment_information']
            module_id=request.POST.get('export')


            if not extra_file:
                assignment=Assignment(due_date=due_date, due_time=due_time, teacher_id=teacher_id,information=information,title=title,course_id_id=val_course, module_id_id=module_id)
                assignment.save();
                return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)
            else:    
                assignment=Assignment(due_date=due_date, due_time=due_time, extra_file=extra_file, teacher_id=teacher_id,information=information,title=title,course_id_id=val_course, module_id_id=module_id)
                assignment.save();
                return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)
       
        elif 'datepicker' in request.POST:
            due_date=request.POST['datepicker']
            due_time=request.POST['timepicker']
            extra_file=request.FILES.get('choose_file')
            title=request.POST['assignment_title']
            information=request.POST['assignment_information']
            module_id=request.POST.get('export')


            if not extra_file:
                assignment=Assignment(due_date=due_date, due_time=due_time, teacher_id=teacher_id,information=information,title=title,course_id_id=val_course, module_id_id=module_id)
                assignment.save();
                return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)
            else:    
                assignment=Assignment(due_date=due_date, due_time=due_time, extra_file=extra_file, teacher_id=teacher_id,information=information,title=title,course_id_id=val_course, module_id_id=module_id)
                assignment.save();
                return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)



        # if the make announcemnt form is selected
        elif 'announcement_title' in request.POST and request.FILES.get('choose_file'):
            title_announcement=request.POST['announcement_title']
            information_announcement=request.POST['announcement_information']
            extra_file_announcement=request.FILES.get('choose_file')
            module_id_announcement=request.POST.get('export1')

            if not extra_file_announcement:
                announcement=Announcement(title=title_announcement, information=information_announcement, course_id_id=val_course, module_id_id=module_id_announcement, teacher_id=teacher_id)
                announcement.save()
                return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)
            else:
                announcement=Announcement(title=title_announcement, information=information_announcement, course_id_id=val_course, module_id_id=module_id_announcement, teacher_id=teacher_id, extra_file=extra_file_announcement)
                announcement.save()
                return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)


        elif 'announcement_title' in request.POST:
            title_announcement=request.POST['announcement_title']
            information_announcement=request.POST['announcement_information']
            extra_file_announcement=request.FILES.get('choose_file')
            module_id_announcement=request.POST.get('export1')

            if not extra_file_announcement:
                announcement=Announcement(title=title_announcement, information=information_announcement, course_id_id=val_course, module_id_id=module_id_announcement, teacher_id=teacher_id)
                announcement.save()
                return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)
            else:
                announcement=Announcement(title=title_announcement, information=information_announcement, course_id_id=val_course, module_id_id=module_id_announcement, teacher_id=teacher_id, extra_file=extra_file_announcement)
                announcement.save()
                return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)


        # to delete the assignment post
        elif 'delete_assignment' in request.POST:
            id=request.POST['delete_assignment']
            try:
                assignment_delete=Assignment.objects.filter(assignment_id=id)
                assignment_delete.delete()
            except:
                pass
            return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)


        # to delete the announcement post
        elif 'delete_announcement' in request.POST:
            id=request.POST['delete_announcement']
            try:
                assignment_delete=Announcement.objects.filter(announcement_id=id)
                assignment_delete.delete()
            except:
                pass
            return redirect(('/assignment.teacher/') + '?' + 'name='+ module_name)


    context={
        "assignment":assignment_send,
        "announcement":announcement,
        "student_assignment_id":student_assignment_id
    }

    return render(request, 'content/assignment_teacher.html', context)



@login_required()
def assignment_student_view(request):
    module_name=request.GET.get('name')
    print(module_name)

    now=datetime.now()
    current_date=now.date()
    current_time = now.time()

    assignment=list(Assignment.objects.filter(module_id_id=module_name).values_list('assignment_id','due_date','due_time','extra_file', 'module_id_id', 'information','title').order_by('-assignment_id'))
    announcement=list(Announcement.objects.filter(module_id_id=module_name).values_list('announcement_id','title','information','extra_file','module_id_id').order_by('-announcement_id'))
    
    assignment_student=list(Assignment_student.objects.filter(module_id_id=module_name).values_list('file','submitted_on','real_assignment_id_id').order_by('-real_assignment_id_id'))

        
    if request.method=='POST' or  request.FILES.get('file_to_submit'):
        user_id=request.user
        course=CustomUser.objects.filter(username=user_id).values('course')
        for c in course:
            val_course=c['course']

        student_id=user_id

        

        # if 'file_to_submit' in request.POST:
        file=request.FILES.get('file_to_submit')
        insert_assignment=request.POST['assignment_id']
        print(file)
        print(insert_assignment)
        
        assignment=Assignment_student(student_id=student_id,real_assignment_id_id=insert_assignment, course_id_id=val_course, module_id_id=module_name,file=file)
        assignment.save();
        # print("file sended")
        return redirect(('/assignment.student/') + '?' + 'name='+ module_name)

    context={
        "assignment":assignment,
        "announcement":announcement,
        "assignment_student":assignment_student,
        'current_date':current_date,
        'current_time':current_time
    }
    return render(request, 'content/assignment_student.html',context)

@login_required()
def notice_view(request):
    notice_list1=list(Notice.objects.values_list('notice_title','notice','notice_date').order_by('-notice_date'))
    context={
        'notice_list1':notice_list1
    }
    return render(request, 'content/notice.html',context)

@login_required()
def notice_teacher_view(request):
    notice_list2=list(Notice.objects.values_list('notice_title','notice','notice_date').order_by('-notice_date'))
    context={
        'notice_list2':notice_list2
    }
    return render(request, 'content/notice_teacher.html',context)


@login_required()
def certificate_view(request):
    if request.method=='GET':
        user=request.user
        certificate_list=list(Certificate.objects.filter(user_id=user).values_list('full_name','certificate_reason','certificate_date'))
        print(certificate_list)
        context={
            'certificate_list':certificate_list
        }
    return render(request, 'content/certificate.html',context)

@login_required()
def pdf_certificate(request):
    user=request.user
    certificate_list=list(Certificate.objects.filter(user_id=user).values_list('full_name','certificate_reason','certificate_date'))
    print(certificate_list)
    
    template_path = 'content/pdf_certificate.html'
    # Create a Django response object, and specify content_type as pdf
    context={
        'certificate_list':certificate_list
    }
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'filename="certificate.pdf"'
    # find the template and render it.
    template = get_template(template_path)
    html = template.render(context)

    # create a pdf
    pisa_status = pisa.CreatePDF(
       html, dest=response)
    # if error then show some funy view
    if pisa_status.err:
       return HttpResponse('We had some errors <pre>' + html + '</pre>')
    return response

@login_required()
def certificate_teacher_view(request):
    if request.method=='GET':
        user=request.user
        certificate_list=list(Certificate.objects.filter(user_id=user).values_list('full_name','certificate_reason','certificate_date'))
        print(certificate_list)
        context={
            'certificate_list':certificate_list
        }
    return render(request, 'content/certificate_teacher.html',context)

@login_required()
def pdf_certificate_teacher(request):
    user=request.user
    certificate_list=list(Certificate.objects.filter(user_id=user).values_list('full_name','certificate_reason','certificate_date'))
    print(certificate_list)
    
    template_path = 'content/pdf_certificate_teacher.html'
    # Create a Django response object, and specify content_type as pdf
    context={
        'certificate_list':certificate_list
    }
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'filename="certificate.pdf"'
    # find the template and render it.
    template = get_template(template_path)
    html = template.render(context)

    # create a pdf
    pisa_status = pisa.CreatePDF(
       html, dest=response)
    # if error then show some funy view
    if pisa_status.err:
       return HttpResponse('We had some errors <pre>' + html + '</pre>')
    return response

@login_required()
def result_teacher(request):

    
    if request.method=='GET':
        user_id=request.user

        teacher_course=Teacher.objects.filter(username=user_id).values('course')
      
        students=Student.objects.values_list('id','full_name','course','level')

        teacher_module=Teacher.objects.filter(username=user_id).values_list('four','five','six')

        marks=Result.objects.values_list('student_id_id','marks')

    if request.method=='POST':    

        # table data
        student_id=request.POST['student_id']
        student_name=request.POST['student_name']
        course=request.POST['course']
        level=request.POST['level']
        module=request.POST['module']
        marks=request.POST.get('marks')

        print(student_id,student_name,course,level,module,marks)

        update,create=Result.objects.update_or_create(student_id_id=student_id,student_name=student_name,course_id=course, level_id=level,module_id=module,defaults={'marks':marks})
        # trying to store data in database up to here



        return redirect('/result-teacher/')

    context={
        'students':students,
        'teacher_course':teacher_course,
        'teacher_module':teacher_module,
        'marks':marks
    }

    return render(request, 'content/result_teacher.html',context)

@login_required()
def result_student_view(request):
    user=request.user
    result=Result.objects.filter(student_id_id=user).values_list('student_id_id','student_name','course_id','level_id','module_id','marks','is_active')
    print(result)

    context={
        'result':result
    }
    return render(request, 'content/result_student.html', context)

@login_required()
def profile_student_view(request):
    user=request.user
    profile=Student.objects.filter(username=user).values_list('username','full_name','date_joined','email','gender','course','level')
    context={
        'profile':profile
    }
    return render(request, 'content/profile_student.html',context)

def profile_teacher_view(request):
    user=request.user
    profile=Teacher.objects.filter(username=user).values_list('username','full_name','date_joined','email','gender','course','four','five','six')
    context={
        'profile':profile
    }
    return render(request, 'content/profile_teacher.html',context)



@login_required()
def exam_view(request):
    user=request.user
    context={
        'user':user
    }
    return render(request, 'content/exam.html',context)